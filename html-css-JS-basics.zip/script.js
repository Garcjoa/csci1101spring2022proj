let counter= 0;

// camelCase
function buttonClicked ()
  {
    counter++;

    let clickedCounterElement = document.getElementById("clickcounter");

    clickedCounterElement.innerHTML = "Clicket " + counter + " times.";
  }

let clickedButtonElement = Document.getElementById("clickbutton");

clickedButtonElement.addEventListener("click", buttonClicked);